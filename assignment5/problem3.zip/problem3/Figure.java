package MPP.assignment5.problem3;

// base interface for all types of figures
public interface Figure {

	public double computeArea();
}
