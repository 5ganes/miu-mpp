package MPP.assignment5.problem1.rulesets;

@SuppressWarnings("serial")
public class RuleException extends Exception {
	public RuleException() {
		super();
	}
	public RuleException(String msg) {
		super(msg);
	}
}
