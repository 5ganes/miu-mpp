package MPP.assignment5.problem2;

public interface QuackBehavior {
	abstract void quack();
}
