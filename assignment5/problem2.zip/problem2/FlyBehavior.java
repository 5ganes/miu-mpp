package MPP.assignment5.problem2;

public abstract interface FlyBehavior {
	abstract void fly();
}
