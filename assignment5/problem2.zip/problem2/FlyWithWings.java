package MPP.assignment5.problem2;

public class FlyWithWings implements FlyBehavior {

	@Override
	public void fly() {
		System.out.println("\tfly with wings");
	}
}
