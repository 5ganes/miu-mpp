package MPP.assignment5.problem2;

public class Quack implements QuackBehavior {

	@Override
	public void quack() {
		System.out.println("\tquacking");
	}

}
